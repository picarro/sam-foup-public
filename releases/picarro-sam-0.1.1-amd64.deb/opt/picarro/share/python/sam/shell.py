#!/usr/bin/python3 -i
#===============================================================================
## @file demoshell.py
## @brief Interactive service control via collection of clients.
## @author Tor Slettnes <tslettnes@picarro.com>
#===============================================================================

### Set up import path
import sys, pathlib, os.path
sys.path.insert(0, os.path.realpath(pathlib.Path(__file__).parent.parent))

### Modules relative to install folder
from core.timeutil import isotime
from protobuf.import_proto \
    import import_wellknown_protos, import_core_protos, import_proto

import sam.crds.core
import sam.crds.core.tests.test_get_points
import sam.crds.grpc.data_client
import sam.crds.rest.data_client

import sam.foup.core
import sam.foup.grpc.client

import sam.controller.core
import sam.controller.grpc.client

import protobuf.utils
import protobuf.wellknown
import protobuf.variant
import protobuf.signal
import protobuf.status
import protobuf.rr

### Third-party modules
import google.protobuf.message

### Standard Python modules
import logging
import argparse
import sys
import os.path
import time
import enum

## Import well-known ProtoBuf modules from Google. Their symbols will appear within
## the namespace that matches their `package` declarations: `google.protobuf`.
import_wellknown_protos(globals())

## Import core ProtoBuf modules. Their symbols will appear within namespaces
## that matches their respective `package` declarations: picarro.*.
import_core_protos(globals())

## Import SAM-specific ProtoBuf modules.  Symbols will appear in namespaces
## matching their respecive package declarations: `picarro.sam`, `picarro.foup`.
import_proto('controller', globals())
import_proto('crds_data', globals())
import_proto('porthistory', globals())
import_proto('foup', globals())
#import_proto('samlet', globals())

AggregationType = enum.Enum('AggregationType', picarro.sam.crds.AggregationType.items())

### Add a few arguments to the base argparser
class ArgParser (argparse.ArgumentParser):
    def __init__ (self, prog=os.path.basename(sys.argv[0]), identity="DemoShell", *args, **kwargs):
        super().__init__(prog=prog, *args, **kwargs);

        self.add_argument('--host',
                          type=str,
                          default="localhost",
                          help="Host for remote services")

        self.add_argument('--debug',
                          default=False,
                          action='store_const',
                          const=True,
                          help='Print debug messages')

def test_get_points(implementation,
                    start,
                    end,
                    aggregation : AggregationType = AggregationType.PROCESSED):

    tester = sam.crds.core.tests.test_get_points.GetPointsTester()

    ### If using AsyncIO, this may return a coroutine that needs to be `await`ed
    return tester.run(implementation, start, end, protobuf.utils.enumToValue(aggregation))


def legend():
    '''
    Interactive Service Control.  Subsystems loaded:

        crds       - CRDS Data gRPC client
        crds_rest  - CRDS Data REST client
        foup       - FOUP gRPC client
        controller - Controller client

    ProtoBuf types are generally loaded into namespaces matching the package
    names from their respective `.proto` files:

        google.protobuf - Well-known types from Google
        picarro.*       - Picarro custom types
        picarro.sam.*   - Custom types specific to SAM
        protobuf.*      - General utilities and wrapper modules

    Use 'help(subsystem)' to list available methods
    '''
    print(legend.__doc__)


if __name__ == "__main__":
    args   = ArgParser().parse_args()

    logger = logging.getLogger()
    logger.setLevel((logging.INFO, logging.DEBUG)[args.debug])

    crds        = sam.crds.grpc.data_client.DataClient(args.host)
    crds_rest   = sam.crds.rest.data_client.DataClient()
    foup        = sam.foup.grpc.client.Client(args.host)
    controller  = sam.controller.grpc.client.Client(args.host)

    crds.initialize()
    crds_rest.initialize()
    foup.initialize()
    controller.initialize()

    legend()

