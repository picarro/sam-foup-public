#!/bin/echo Do not invoke directly.
#===============================================================================
## @file data_client.py
## @brief Python client for the "customer API" REST API service from SAM core
## @author Tor Slettnes <tslettnes@picarro.com>
#===============================================================================

### Modules relative to current dir
from ..core.data import Data, AggregationType, signal_datapoint

### Modules relative to install dir
from messaging.rest.client import RESTClient
from core.scheduler import scheduler, TaskAlignment
from protobuf.utils import check_type, enumToValue, valueToEnum
from protobuf.import_proto import import_proto

### Standard Python modules
from typing import Sequence, Iterator, Mapping, Any
import threading
import logging
import json
import enum

### Import generated types from `crds_data`. These will appear within the
### namespace `picarro.sam.crds`.
import_proto('crds_data', globals())

DataPointType = Mapping[str, Any]

class DataClient (Data):
    '''Client for SAM Data REST service.'''

    ### Used to look up service settings (e.g. path, poll interval, ...)
    service_name = 'Data'

    aggregation_type_names = {
        AggregationType.RAW : "raw",
        AggregationType.PROCESSED : "processed",
        AggregationType.ROLLING_AVERAGE : "rolling_avg",
        AggregationType.PORT_AVERAGE : "port_avg"
    }

    def __init__(self,
                 base_url : str = ""):

        Data.__init__(self)

        self._scheduler_handle = None
        self.rest_client = RESTClient(base_url, service_name = self.service_name)
        self.poll_interval = self.rest_client.setting("poll interval", 15.0)

    @property
    def keys(self):
        try:
            keys = self._keys
        except AttributeError:
            keys = self._keys = self.get_keys().keys

            try:
                keys.remove("CavityTemp")
            except ValueError:
                pass

            try:
                keys.remove("CavityPressure")
            except ValueError:
                pass

        return keys

    def get_keys(self) -> list[str]:
        return self._extract_keys(self.rest_client.get_json("/getkeys"))

    def get_last_point(self) -> DataPointType:
        return self._extract_last_point(self.keys,
                                        self.rest_client.get_json("/getpoints"))

    def _aggregation_type(self,
                          candidate: AggregationType = AggregationType.DEFAULT):

        aggregation = protobuf.utils.valueToEnum(candidate)
        if aggregation == AggregationType.DEFAULT:
            aggregation = AggregationType.RAW

        return aggregation

    def _get_points(self,
                   request: picarro.sam.crds.PointsRequest
                   ) -> Iterator[DataPointType]:

        check_type(request, picarro.sam.crds.PointsRequest)

        kwargs = {}

        epoch_start = request.starttime.ToSeconds()
        epoch_end = request.endtime.ToSeconds()

        if (epoch_start and epoch_end):
            kwargs.update({'from':epoch_start, 'to':epoch_end, 'epoch':True})

        aggregation = self._aggregation_type(request.aggregation)
        typename = self.aggregation_type_names.get(aggregation)
        kwargs.update({'aggregation-type':typename})

        return self._extract_datapoints(
            aggregation,
            request.compounds or self.keys,
            self.rest_client.get_json("/getpoints", kwargs=kwargs))

    def _start_streaming(self):
        '''Start streaming data points from server, emitting
        `signal_datapoint` for each point received.

        This is invoked from `Data.StartStreaming(callback)` once the first
        callback function is registered and connected to this signal.
        '''

        if not self._scheduler_handle:
            self._sheduler_handle = scheduler.add(
                handle = None,
                interval = self.poll_interval,
                method = lambda: signal_datapoint.emit(self.get_last_point()),
                align = TaskAlignment.UTC)

    def _stop_streaming(self):
        '''Stop streaming data points from server.

        This is invoked from `Data.StartStreaming(callback)` once the last
        callback function is disconnected from `signal_datapoint`.
        '''

        if handle := self._scheduler_handle:
            self._scheduler_handle = None
            scheduler.remove(handle)

    def _extract_keys(self, received: map):
        return picarro.sam.crds.DataKeys(keys=received.get("keys", []))

    def _extract_last_point(self,
                            compounds: Sequence[str],
                            received: map):

        if points := self._extract_datapoints(self._aggregation_type(), compounds, received):
            for point in points:
                return point
        else:
            return None

    def _extract_datapoints(self,
                            aggregation: AggregationType,
                            compounds: Sequence[str],
                            received: map):
        for point in received.get("points", []):
            yield self._extract_single_point(aggregation, compounds, point)

    def _extract_single_point(self,
                              aggregation: AggregationType,
                              compounds: Sequence[str],
                              json_map: dict):

        point = picarro.sam.crds.DataPoint()
        point.aggregation = protbuf.utils.enumToValue(aggregation)

        if value := json_map.get("time"):
            point.time.FromMilliseconds(value)

        if value := json_map.get("CavityTemp"):
            point.cavity_temperature = value

        if value := json_map.get("CavityPressure"):
            point.cavity_pressure = value

        if value := json_map.get("fdc_flag"):
            # This should be an boolean, but the REST API sends it as a string
            point.fdc_flag = bool(int(value))

        if value := json_map.get("fdc_events"):
            # This should be a list, but the REST API returns it as a nested JSON string
            try:
                point.fdc_events.extend(eval(value))
            except Exception as e:
                point.fdc_events.append(value)

        for key in ("model_number", "recipe_name", "port", "port_label"):
            if value := json_map.get(key):
                setattr(point, key, value)

        for (index, compound) in enumerate(compounds):
            point.compounds[index] = compound

            if value := json_map[compound]:
                point.concentrations[index].measured = value

                if threshold := json_map.get(compound + "_thresh"):
                    point.concentrations[index].threshold = threshold

        # point.compounds.update(compounds)
        return point
