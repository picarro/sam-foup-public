#!/usr/bin/echo Do not invoke directly.
#===============================================================================
## @file __init__.py
## @brief Generic messaging base
## @author Tor Slettnes <tslettnes@picarro.com>
#===============================================================================

from .endpoint import Endpoint
