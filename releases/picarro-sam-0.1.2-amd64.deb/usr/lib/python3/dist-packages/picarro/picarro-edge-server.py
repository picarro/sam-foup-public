#!/usr/bin/python3 -i
#===============================================================================
## @file picarro-edge-server.py
## @brief Python flavor of Picarro EDGE server using threads
## @author Tor Slettnes <tslettnes@picarro.com>
#===============================================================================

### Modules relative to install dir
from sam.crds.grpc.data_service import DataService as CRDSDataService
from sam.crds.rest.data_client import DataClient as CRDSDataClient
from picarro.messaging.grpc.server import create_server

### Standard Python modules
import logging

def main():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    data_client = CRDSDataClient()
    data_service = CRDSDataService(data_client)
    server = create_server(data_service)

    try:
        logging.info("Starting Python Edge Server")
        server.start()
        server.wait_for_termination()
    except KeyboardInterrupt:
        pass
    finally:
        logging.info("Shutting down Python Edge Server")
        server.stop(5)

if __name__ == '__main__':
    main()
