#!/bin/echo Do not invoke directly.
#===============================================================================
## @file data_service.py
## @brief Handle `picarro.sam.crds.Data` gRPC service requests
## @author Tor Slettnes <tslettnes@picarro.com>
#===============================================================================

### Modules relative to current tdir
from ..core.data import Data

### Modules relative to install dir
from picarro.messaging.grpc.service import Service
from picarro.protobuf.import_proto import import_proto

### Third-party modules
import grpc

### Standard Python modules
from typing import Generator
from asyncio import Queue

### Generated service interface from `crds_data.proto`
from crds_data_pb2_grpc import DataServicer

### Generated data types from `crds_data.proto`.
### These will appear in the namespace `picarro.sam.crds`
import_proto('crds_data', globals())


## We derive our service class from
##
##  - `Service`, the common service base, e.g. to load service settings.
##
##  - `DataServicer`, generated from the `service Data` block in `crds_data.proto`.
##    Strictly speaking it would not be necessary to derive from this class since
##    Python does not have a concept of pure virtual methods and overrides, but
##      (a) it helps the `Service` base class determine the service name, which is
##          in t urn used to look up settings such as listening port,
##      (b) it ensures all service methods listed in the `.proto` file are
##          defined, even if not overridden here, so that the server can start, and
##      (c) doing so is in accordance with the official guide at https://grpc.io/,
##          and should as such be considered more future proof.

class DataService (Service, DataServicer):
    '''Handle `crds.Data` service requests'''

    def __init__ (self,
                  api_provider : Data,
                  bind_address : str = "",
                  max_queue_size : int = 0):
        Service.__init__(self, bind_address)
        self.api_provider = api_provider
        self._max_queue_size = max_queue_size

    def get_keys(self,
                  request: ProtoBuf.Empty,
                  context: grpc.ServicerContext) -> picarro.sam.crds.DataKeys:

        return self.api_provider.get_keys()

    def get_last_point(self,
                       request: ProtoBuf.Empty,
                       context: grpc.ServicerContext) -> picarro.sam.crds.DataPoint:

        return self.api_provider.get_last_point()

    def get_points(self,
                   request: picarro.sam.crds.PointsRequest,
                   context: grpc.ServicerContext
                   ) -> Generator[None, picarro.sam.crds.DataPoint, None]:

        for point in self.api_provider.get_points(request):
            yield point


    def stream_points(self,
                      request: ProtoBuf.Empty,
                      context: grpc.ServicerContext
                      ) -> Generator[None, picarro.sam.crds.DataPoint, None]:

        queue = Queue(self._max_queue_size)
        handle = self.api_provider.start_listening(queue.put)

        try:
            while msg := queue.get():
                yield msg

        finally:
            self.api_provider.stop_listening(handle)
