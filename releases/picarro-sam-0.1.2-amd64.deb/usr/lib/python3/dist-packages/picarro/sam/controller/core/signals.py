#!/bin/echo Do not invoke directly.
#===============================================================================
## @file signals.py
## @brief Local signal store for Controller service
## @author Tor Slettnes <tslettnes@picarro.com>
#===============================================================================

### Modules relative to install dir
from picarro.protobuf.signal import SignalStore

### Generated from `.proto` fils
from controller_pb2 import Signal

#===============================================================================
# Signal store to propagate `greeting` and `time` signals for application.

signal_store = SignalStore(use_cache=True, signal_type = Signal)
