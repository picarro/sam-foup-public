#!/bin/echo Do not invoke directly.
#===============================================================================
## @file data_client.py
## @brief Python client for `picarro.sam.crds.Data` gRPC service
## @author Tor Slettnes <tslettnes@picarro.com>
#===============================================================================

### Modules relative to current dir
from ..core.data import Data, signal_datapoint

### Modules relative to install dir
from picarro.messaging.grpc import Client, ThreadReader, AsyncReader
from picarro.protobuf.utils import check_type
from picarro.protobuf.import_proto import import_proto, import_wellknown_protos
from picarro.protobuf.wellknown import Empty

### Standard Python modules
from typing import Iterator
import threading

### Import well-known ProtoBuf types from Google.
### These will appear in the namespace `google.protobuf`.
import_wellknown_protos(globals())

### Import generated CRDS data types.
### These will appear in the namespace `picarro.sam.crds`.
import_proto('crds_data', globals())


class DataClient (Data, Client):
    '''Client for SAM Data gRPC service.'''

    ## `Stub` is the generated gRPC client Stub, and is used by the
    ## `messaging.grpc.Client` base to instantiate `self.stub`.
    from crds_data_pb2_grpc import DataStub as Stub

    def __init__(self,
                 host           : str = "",      # gRPC server
                 identity       : str = None,    # Greeter identity
                 wait_for_ready : bool = False,  # Keep trying to connect
                 use_asyncio    : bool = False): # Use Python AsyncIO semantics

        Data.__init__(self)
        Client.__init__(self,
                        host = host,
                        wait_for_ready = wait_for_ready,
                        use_asyncio = use_asyncio)

        self._keepalive = False
        self._point_stream = None
        self._points_reader = (ThreadReader, AsyncReader)[self.use_asyncio]()

    def get_keys(self) -> picarro.sam.crds.DataKeys:
        return self.stub.get_keys(Empty())

    def get_last_point(self) -> picarro.sam.crds.DataPoint:
        return self.stub.get_last_point(Empty())

    def _get_points(self,
                    request: picarro.sam.crds.PointsRequest
                    ) -> Iterator[picarro.sam.crds.DataPoint]:
        check_type(request, picarro.sam.crds.PointsRequest)
        return self.stub.get_points(request)

    def _start_streaming(self):
        '''Start streaming data points from server, emitting
        `signal_datapoint` for each point received.

        This is invoked from `Data.start_listening(callback)` once the first
        callback function is registered and connected to this signal.
        '''

        self._points_stream = self.stub.stream_points(Empty())
        self._points_reader.start(self._points_stream, signal_datapoint.emit)

    def _stop_streaming(self):
        '''Stop streaming data points from server.

        This is invoked from `Data.StartStreaming(callback)` once the last
        callback function is disconnected from `signal_datapoint`.
        '''
        if stream := self._point_stream:
            stream.cancel()

