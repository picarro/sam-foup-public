#!/bin/echo Do not invoke directly.
#===============================================================================
## @file client.py
## @brief Picarro SAM - Python wrapper for Controller gRPC service
## @author Tor Slettnes <tslettnes@picarro.com>
#===============================================================================

## Modules relative to current dir
from ..core.signals import signal_store

### Modules relative to install dir
from picarro.messaging.grpc import SignalClient
from picarro.protobuf.import_proto import import_proto

## Standard Python modules
from typing import Callable

## Import generated types. These will appear in namespaces
## corresponding to their respective ProtoBuf package names,
## e.g. `picarro.sam.controller`.
import_proto('controller', globals())

SignalSlot = Callable[[picarro.sam.controller.Signal], None]


class Client (SignalClient):
    '''Controller Client implementation'''

    from picarro.generated.controller_pb2_grpc import ControllerStub as Stub

    def __init__(self,
                 host           : str = "",      # gRPC server
                 wait_for_ready : bool = False,  # Keep trying to connect
                 use_asyncio    : bool = False): # Use Python AsyncIO semantics

        SignalClient.__init__(self,
                              host = host,
                              wait_for_ready = wait_for_ready,
                              use_asyncio = use_asyncio,
                              signal_store = signal_store,
                              watch_all = False)


    def start_notify_signals(self, callback: SignalSlot):
        '''Register a callback whenver any signal event is received.

        If we are not yet watching signals from the server, do so now.

        '''
        self.signal_store.connect_all(callback)
        self.start_watching(True)


    def stop_notify_signals(self):
        '''
        Unregister a callback from signal notifications
        '''
        self.signal_store.disconnect_all()


