#!/usr/bin/python3 -i
#===============================================================================
## @file picarro-edge-asyncio-server.py
## @brief Python flavor of Picarro EDGE server using AsyncIO semantics
## @author Tor Slettnes <tslettnes@picarro.com>
#===============================================================================

### Modules relative to install dir
from sam.grpc.public_service import PublicService
from sam.rest.public_client import PublicClient
from picarro.messaging.grpc.server import create_server

### Standard Python modules
import logging
import asyncio

async def main():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    public_client = PublicClient()
    public_service = PublicService(public_client)
    server = create_server(public_service)

    try:
        logging.info("Starting Python Edge Server")
        await server.start()
        await server.wait_for_termination()
    except KeyboardInterrupt:
        pass
    finally:
        logging.info("Shutting down Python Edge Server")
        await server.stop(5)

if __name__ == '__main__':
    asyncio.run(main())
