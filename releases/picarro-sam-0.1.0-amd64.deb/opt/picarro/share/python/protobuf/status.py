#!/usr/bin/echo Do not invoke directly.
#===============================================================================
## @file status.py
## @brief Wrapper module for `status.proto`
## @author Tor Slettnes <tslettnes@picarro.com>
#===============================================================================

### Populate symbols from `request_reply.proto`
from generated.status_pb2 import *
