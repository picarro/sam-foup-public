#!/bin/echo Do not invoke directly.
#===============================================================================
## @file foup_client.py
## @brief Picarro SAM - FOUP Python API
## @author Tor Slettnes <tslettnes@picarro.com>
#===============================================================================

## Modules relative to current dir
from ..core.signals import signal_store

### Modules relative to install dir
from messaging.grpc import SignalClient
from protobuf.utils import enumToValue
from protobuf.wellknown import Empty, encodeDuration
from protobuf.import_proto import import_proto

## Standard Python modules
from typing import Optional, Callable, List, Iterator, Union
import sys, os.path, time, datetime, threading, logging, enum, collections

## Import generated types. These will appear in namespaces
## corresponding to their respective ProtoBuf package names,
## e.g. `picarro.sam.foup`.
import_proto('foup', globals())


Timestamp = int | float | str | time.struct_time | datetime.datetime
Duration = int | float
SignalSlot = Callable[[picarro.sam.foup.Signal], None]
VersionTuple = collections.namedtuple('Version', ('major', 'minor', 'tweak'))

ActionType = enum.Enum('ActionType', picarro.sam.foup.ActionType.items())
JobID = str

#===============================================================================
# Base FOUP implementation

class Client (SignalClient):
    '''FOUP Base implementation'''

    ## `Stub` is the generated gRPC client Stub, and is used by the
    ## `messaging.grpc.Client` base to instantiate `self.stub`.
    from generated.foup_pb2_grpc import FOUPStub as Stub

    ## `service_name` is optional. If not provided here it is determined
    ## from the above stub.  It is used to look up service specific settings,
    ## such as target host/port.
    service_name = None

    ## `signal_type` is required only if we don't provide a an existing
    ## SignalStore() instance to the `SignalClient.__init__()` base, below.
    ## In our case we do, since we share the signal store with other message
    ## clients which also receive and re-emit signals from remote endpoints.
    #signal_type = protobuf.demo.Signal

    def __init__(self,
                 host           : str = "",      # gRPC server
                 wait_for_ready : bool = False,  # Keep trying to connect
                 use_asyncio    : bool = False): # Use Python AsyncIO semantics

        SignalClient.__init__(self,
                              host = host,
                              wait_for_ready = wait_for_ready,
                              use_asyncio = use_asyncio,
                              signal_store = signal_store,
                              watch_all = False)

    def get_service_info(self) -> picarro.sam.foup.ServiceInfo:
        '''
        Obtain service information from the server.
        '''
        return self.stub.get_service_info(Empty())


    def check_service_compatibility(self, strict: bool = True) -> bool:
        '''
        Compare Client and Server API versions to ensure compatibility.

        The `major` component must match. Additionally, if `strict` is set,
        the `minor` version must be equal to or higher on the server than the client.
        '''

        server_api = self.get_server_api_version()
        client_api = self.get_client_api_version()

        return ((server_api.major == client_api.major) and
                ((server_api.minor >= client_api.minor) or not strict))


    def get_server_api_version(self) -> VersionTuple:
        '''Get the server's FOUP API version.'''

        api_version = self.get_service_info().api_version
        return VersionTuple(api_version.major, api_version.minor, api_version.tweak)

    def get_client_api_version(self) -> VersionTuple:
        '''Get our own (client) FOUP API version.'''

        return VersionTuple(int(picarro.sam.foup.APILEVEL_MAJOR),
                            int(picarro.sam.foup.APILEVEL_MINOR),
                            int(picarro.sam.foup.APILEVEL_TWEAK))


    def start_job(self,
                  action: ActionType,
                  foup_id: str,
                  duration: Duration) -> str:
        '''Start a new measurement.  Returns the Job ID.

        '''
        request = picarro.sam.foup.JobInputs(
            action = enumToValue(action),
            foup_id = foup_id,
            duration = encodeDuration(duration))
        response = self.stub.start_job(request)
        return response.id


    def abort_job(self,
                  job_id: str) -> bool:
        '''
        Cancel the current measurement. If a job identity is provided, cancel
        only if it matches the current job.
        '''

        request = picarro.sam.foup.JobIdentity(id = job_id)
        response = self.stub.abort_job(request)
        return response.aborted

    def get_result(self,
                    job_id: str) -> picarro.sam.foup.JobResult:
        '''
        Get result from a specific completed measurement.
        '''

        request = picarro.sam.foup.JobIdentity(id = job_id)
        return self.stub.get_result(request)


    def start_notify_signals(self, callback: SignalSlot):
        '''Register a callback whenver any signal event is received.

        If we are not yet watching signals from the server, do so now.

        '''
        self.signal_store.connect_all(callback)
        self.start_watching(True)


    def stop_notify_signals(self):
        '''
        Unregister a callback from signal notifications
        '''
        self.signal_store.disconnect_all()


    def start_notify_job_status(self, callback: SignalSlot):
        '''Register a callback whenver a job status update is received.

        If we are not yet watching signal events from the server, do so now.

        '''
        self.signal_store.connect_signal('job_status', callback)
        self.start_watching(True)


    def stop_notify_job_status(self):
        '''
        Unregister a callback from job status notifications
        '''
        self.signal_store.disconnect_signal('job_status')
