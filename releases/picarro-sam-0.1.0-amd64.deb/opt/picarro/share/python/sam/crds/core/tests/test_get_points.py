#!/usr/bin/python3 -i
#===============================================================================
## @file get_points.py
## @brief Test throughput of crds.Data().get_points() function
## @author Tor Slettnes <tslettnes@picarro.com>
#===============================================================================

### Generated ProtoBuf modules
import crds_data_pb2 as crds_data

### Modules relative to current folder
from ..data import Data

### Modules relative to install folder
from core.timeutil import isotime
from protobuf.wellknown import TimestampType, encodeTimestamp
from protobuf.utils import messageToDict

### Standard Python modules
import time


class GetPointsTester (object):

    def run(self,
            implementation : Data,
            start : TimestampType,
            end : TimestampType,
            aggregation : crds_data.AggregationType = crds_data.PROCESSED):

        self.implementation = implementation
        self.request = crds_data.PointsRequest(
            starttime = encodeTimestamp(start),
            endtime = encodeTimestamp(end),
            aggregation = aggregation)
        self.received_count = 0

        try:
            use_async = self.implementation.use_asyncio
        except AttributeError:
            use_async = False

        if use_async:
            # Return a coroutine that needs to be `await`ed
            return self.run_async()
        else:
            # Run the test
            return self.run_sync()

    async def run_async(self):
        async for point in self._get_reader():
            self._process_point(point)

        self._summarize()

    def run_sync(self):
        for point in self._get_reader():
            self._process_point(point)

        self._summarize()

    def _get_reader(self):
        self.test_start = time.time()
        print("t=%s, sending request"%(isotime(self.test_start),))
        reader = self.implementation._get_points(self.request)
        now = time.time()
        print("t=%s, elapsed=%.3f, received streaming handle"%
              (isotime(now), now - self.test_start))
        return reader

    def _process_point(self, point):
        if not self.received_count:
            now = time.time()
            print("t=%s, elapsed=%.3f, received first point: %s"%
                  (isotime(now), now - self.test_start, messageToDict(point)))

        self.received_count += 1
        if self.received_count % 100000 == 0:
            now = time.time()
            print("t=%s, elapsed=%.3f, received %d points"%
                  (isotime(now), now - self.test_start, self.received_count))

    def _summarize(self):
        now = time.time()
        print("t=%s, elapsed=%.3f, received all %d points"%
              (isotime(now), now - self.test_start, self.received_count))
