#!/bin/echo Do not invoke directly.
#===============================================================================
## @file data.py
## @brief Picarro SAM - CRDS Data Python API
## @author Tor Slettnes <tslettnes@picarro.com>
#===============================================================================

## Modules relative to install dir
from core.signal_slot import DataSignal
from core.enumeration import Enumeration

from protobuf.utils import enumToValue
from protobuf.wellknown import encodeTimestamp
from protobuf.import_proto import import_proto

## Standard Python modules
from typing import Optional, Callable, List, Iterator, Union
import sys, os.path, time, datetime, threading, logging, enum

## Import symbols generted from `crds_data.proto`. These will appear in
## the namespace `picarro.sam.crds`
import_proto('crds_data', globals())

Timestamp = int | float | str | time.struct_time | datetime.datetime | None
AggregationType = enum.Enum('AggregationType', picarro.sam.crds.AggregationType.items())

#===============================================================================
# Abstract CRDS Data API implementation

class Data (object):
    '''CRDS Data API'''

    def __init__ (self):
        self._mutex = threading.Lock()
        self._signal_handle = None

    def initialize(self):
        pass

    def deinitialize(self):
        pass

    def get_keys(self) -> picarro.sam.crds.DataKeys:
        '''
        Get available data keys.
        '''
        raise NotImplementedError("Method not implemented by %s"%(self,))


    def get_last_point(self) -> picarro.sam.crds.DataPoint:
        '''Get the most recent data point.
        '''
        raise NotImplementedError("Method not implemented by %s"%(self,))


    def get_points(self,
                   compounds : list[str] | None = None,
                   models : list[str] | None = None,
                   aggregation: AggregationType = AggregationType.RAW,
                   starttime: Timestamp | None = None,
                   endtime: Timestamp | None = None,
                   max_points: int = 0):
        '''
        Get historical data points.

        @param[in] compounds
            Filter by specific compounds.

        @param[in] models
            Filter by specific instrument models.

        @param[in] aggregation
            Aggregation type for concentration values

        @param[in] starttime
            Obtain readings no earlier than the specified time

        @param[in] endtime
            Obtain readings no later than the specified time

        @param[in] max_points
            Maximum number of data points to retrieve
        '''

        return self._get_points(picarro.sam.crds.PointsRequest(
            compounds = compounds,
            models = models,
            aggregation = enumToValue(aggregation),
            starttime = encodeTimestamp(starttime),
            endtime = encodeTimestamp(endtime),
            max_points = max_points))


    def _get_points(self,
                   request: picarro.sam.crds.PointsRequest
                   ) -> Iterator[picarro.sam.crds.DataPoint]:
        '''
        Get historical data points
        '''
        raise NotImplementedError("Method not implemented by %s"%(self,))


    def start_listening(self, callback: Callable[[picarro.sam.crds.DataPoint], None]) -> str:
        '''
        Tell the server to start streaming data points to the specified callback function

        @param[in] callback
             Method to invoke whenever we receive a new data point

        @return
             Unique handle which can be used for a subsequent call to `stop_listening()`
        '''
        with self._mutex:
            streaming = signal_datapoint.connection_count() > 0
            signal_handle = signal_datapoint.connect(callback)
            if not streaming:
                logging.info("%s starting data stream"%(self,))
                self._start_streaming()
                self._signal_handle = signal_handle;
            return signal_handle


    def stop_listening(self, handle: str = None) -> None:
        '''
        Tell the server to stop an existing data stream
        '''
        with self._mutex:
            if handle is None:
                handle = self._signal_handle

            signal_datapoint.disconnect(handle)

            if signal_datapoint.connection_count() == 0:
                logging.info("%s stopping data stream"%(self,))
                self._stop_streaming()


    def _start_streaming(self):
        '''
        Abstract method to start streaming data points
        '''
        raise NotImplementedError("Method not implemented by %s"%(self,))


    def _stop_streaming(self):
        '''
        Abstract method to start streaming data points
        '''
        raise NotImplementedError("Method not implemented by %s"%(self,))


signal_datapoint = DataSignal('point', picarro.sam.crds.DataPoint, True)
