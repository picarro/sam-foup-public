#===============================================================================
## @file build_info.py.in
## @brief Build information template, populated by CMake
## @author Tor Slettnes <tslettnes@picarro.com>
#===============================================================================

PACKAGE_VERSION      = "0.1.0"
PROJECT_VERSION      = "0.1.0"
PROJECT_NAME         = "sam"
PROJECT_DESCRIPTION  = "Picarro SAM applications"
PROJECT_BUILD_DATE   = ""
PROJECT_BUILD_TIME   = ""
